<?php
header("Content-Type: application/json");
error_reporting(E_ALL);
ini_set('display_errors', 0);

/**************** API KEY CHECK ****************/
$API_KEY = "EXAMPACE_SYNC_KEY_2025";
$headers = array_change_key_case(getallheaders(), CASE_UPPER);

if (!isset($headers['X-API-KEY']) || $headers['X-API-KEY'] !== $API_KEY) {
    http_response_code(401);
    echo json_encode(["success" => false, "error" => "Unauthorized"]);
    exit;
}

/**************** INPUT ****************/
$table = preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['table'] ?? '');
if (!$table) {
    echo json_encode(["success" => false, "error" => "Missing table"]);
    exit;
}

/**************** DB CONFIG ****************/
$pdo = new PDO(
    "mysql:host=localhost;dbname=exampace1;charset=utf8mb4",
    "sheet_user",
    "FATIMA@hasan7",
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);

/**************** FETCH COLUMNS ****************/
$stmt = $pdo->prepare("
    SELECT COLUMN_NAME
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = ?
      AND COLUMN_NAME NOT IN ('created_at','updated_at')
");
$stmt->execute([$table]);

$columns = $stmt->fetchAll(PDO::FETCH_COLUMN);

echo json_encode([
    "success" => true,
    "columns" => $columns
]);
