<?php
header("Content-Type: application/json");
error_reporting(E_ALL);
ini_set('display_errors', 0);

/**************** API KEY CHECK ****************/
$API_KEY = "EXAMPACE_SYNC_KEY_2025";

$headers = array_change_key_case(getallheaders(), CASE_UPPER);
if (!isset($headers['X-API-KEY']) || $headers['X-API-KEY'] !== $API_KEY) {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "error" => "Unauthorized"
    ]);
    exit;
}

/**************** DB CONFIG ****************/
$host = "localhost";
$db   = "exampace1";
$user = "sheet_user";
$pass = "FATIMA@hasan7";

/**************** READ INPUT ****************/
$raw = file_get_contents("php://input");
if (!$raw) {
    echo json_encode(["success" => false, "error" => "Empty request"]);
    exit;
}

$data = json_decode($raw, true);
if (!$data || !isset($data['table'])) {
    echo json_encode(["success" => false, "error" => "Invalid JSON payload"]);
    exit;
}

$table     = preg_replace('/[^a-zA-Z0-9_]/', '', $data['table']);
$lastSync  = $data['lastSync'] ?? "1970-01-01 00:00:00";
$sheetIds  = $data['existingIds'] ?? [];

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );

    /************** UPDATED & NEW ROWS **************/
    $params = [$lastSync];
    $where  = "updated_at > ?";

    if (!empty($sheetIds)) {
        $where .= " OR id NOT IN (" . implode(",", array_fill(0, count($sheetIds), "?")) . ")";
        $params = array_merge($params, $sheetIds);
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM `$table`
        WHERE $where
        ORDER BY updated_at ASC
    ");
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    /************** DELETED ROWS **************/
    $deleted = [];
    if (!empty($sheetIds)) {
        $stmt = $pdo->prepare("
            SELECT id
            FROM `$table`
            WHERE id NOT IN (" . implode(",", array_fill(0, count($sheetIds), "?")) . ")
        ");
        $stmt->execute($sheetIds);
        $deleted = $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    echo json_encode([
        "success" => true,
        "rows"    => $rows,
        "deleted" => $deleted
    ]);

} catch (Throwable $e) {
    echo json_encode([
        "success" => false,
        "error"   => $e->getMessage()
    ]);
}
