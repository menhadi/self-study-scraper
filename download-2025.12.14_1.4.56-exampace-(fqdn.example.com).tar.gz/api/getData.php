<?php
require "db.php";

$sql = "SELECT * FROM questions LIMIT 10";
$stmt = $pdo->query($sql);

echo json_encode([
    "success" => true,
    "data" => $stmt->fetchAll()
]);
