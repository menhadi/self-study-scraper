<?php
header("Content-Type: application/json");
error_reporting(E_ALL);
ini_set('display_errors', 0);

/**************** API KEY ****************/
$API_KEY = "EXAMPACE_SYNC_KEY_2025";
$headers = array_change_key_case(getallheaders(), CASE_UPPER);

if (!isset($headers['X-API-KEY']) || $headers['X-API-KEY'] !== $API_KEY) {
    http_response_code(401);
    echo json_encode(["success" => false, "error" => "Unauthorized"]);
    exit;
}

/**************** DB ****************/
$pdo = new PDO(
    "mysql:host=localhost;dbname=exampace1;charset=utf8mb4",
    "sheet_user",
    "FATIMA@hasan7",
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_EMULATE_PREPARES => false
    ]
);

/**************** INPUT ****************/
$data = json_decode(file_get_contents("php://input"), true);
if (!$data || !isset($data['table'], $data['rows'])) {
    echo json_encode(["success" => false, "error" => "Invalid JSON"]);
    exit;
}

$table = preg_replace('/[^a-zA-Z0-9_]/', '', $data['table']);
$rows  = $data['rows'];

if (!count($rows)) {
    echo json_encode(["success" => true, "inserted" => 0]);
    exit;
}

try {
    // 🚨 DISABLE FOREIGN KEY CHECKS
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");

    $count = 0;

    foreach ($rows as $row) {

        // 🚫 Remove system columns
        unset($row['created_at'], $row['updated_at']);

        $cols = array_keys($row);
        $placeholders = array_map(fn($c) => ":$c", $cols);

        $updates = [];
        foreach ($cols as $c) {
            if ($c !== "id") {
                $updates[] = "`$c` = VALUES(`$c`)";
            }
        }

        $sql = "
            INSERT INTO `$table` (`" . implode("`,`", $cols) . "`)
            VALUES (" . implode(",", $placeholders) . ")
            ON DUPLICATE KEY UPDATE " . implode(",", $updates) . "
        ";

        $stmt = $pdo->prepare($sql);

        foreach ($row as $k => $v) {
            if ($v === "" || $v === null || strtolower((string)$v) === "null") {
                $stmt->bindValue(":$k", null, PDO::PARAM_NULL);
            } elseif (is_numeric($v) && ctype_digit((string)$v)) {
                $stmt->bindValue(":$k", (int)$v, PDO::PARAM_INT);
            } else {
                $stmt->bindValue(":$k", $v, PDO::PARAM_STR);
            }
        }

        $stmt->execute();
        $count++;
    }

    // ✅ RE-ENABLE FOREIGN KEY CHECKS
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");

    echo json_encode([
        "success" => true,
        "inserted" => $count
    ]);

} catch (Throwable $e) {
    // SAFETY: re-enable FK even on error
    try { $pdo->exec("SET FOREIGN_KEY_CHECKS = 1"); } catch (_) {}

    echo json_encode([
        "success" => false,
        "error" => $e->getMessage()
    ]);
}
